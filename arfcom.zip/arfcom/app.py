from flask import Flask, render_template, request, redirect
import sqlite3
from datetime import datetime

app = Flask(__name__)
DB = "arfcom.db"

# ================= DATABASE =================
def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

# ================= INIT DB =================
with db() as conn:
    c = conn.cursor()

    c.execute("""
    CREATE TABLE IF NOT EXISTS pelanggan (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT,
        hp TEXT,
        alamat TEXT
    )
    """)

    # ✔ HANYA 1 TABLE (FIX DUPLIKAT ERROR)
    c.execute("""
    CREATE TABLE IF NOT EXISTS servis (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pelanggan_id INTEGER,
        perangkat TEXT,
        kerusakan TEXT,
        status TEXT DEFAULT 'MASUK',
        tanggal TEXT,
        biaya INTEGER DEFAULT 0
    )
    """)

# ================= HOME =================
@app.route('/')
def index():
    with db() as conn:

        pelanggan = conn.execute("SELECT * FROM pelanggan").fetchall()

        servis = conn.execute("""
            SELECT s.*, p.nama as nama_pelanggan
            FROM servis s
            LEFT JOIN pelanggan p ON s.pelanggan_id = p.id
            ORDER BY s.id DESC
        """).fetchall()

        stats = conn.execute("""
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN status='PROSES' THEN 1 ELSE 0 END) as proses,
                SUM(CASE WHEN status='SELESAI' THEN 1 ELSE 0 END) as selesai
            FROM servis
        """).fetchone()

    return render_template("index.html",
                           pelanggan=pelanggan,
                           servis=servis,
                           stats=stats)

# ================= PELANGGAN =================
@app.route('/pelanggan')
def pelanggan():
    with db() as conn:
        data = conn.execute("SELECT * FROM pelanggan ORDER BY id DESC").fetchall()
    return render_template("pelanggan.html", pelanggan=data)

@app.route('/pelanggan/add', methods=['POST'])
def add_pelanggan():
    with db() as conn:
        conn.execute(
            "INSERT INTO pelanggan (nama,hp,alamat) VALUES (?,?,?)",
            (request.form['nama'], request.form['hp'], request.form['alamat'])
        )
    return redirect('/pelanggan')

# ================= SERVIS =================
@app.route('/servis/add', methods=['POST'])
def add_servis():
    with db() as conn:

        pelanggan_id = request.form.get('pelanggan_id')
        perangkat = request.form.get('perangkat', '')
        kerusakan = request.form.get('kerusakan', '')
        biaya = request.form.get('biaya', '0')

        try:
            biaya = int(biaya)
        except:
            biaya = 0

        conn.execute("""
            INSERT INTO servis
            (pelanggan_id, perangkat, kerusakan, status, tanggal, biaya)
            VALUES (?,?,?,?,?,?)
        """, (
            pelanggan_id,
            perangkat,
            kerusakan,
            "MASUK",
            datetime.now().strftime("%Y-%m-%d"),
            biaya
        ))

    return redirect('/')

@app.route('/servis/status/<int:id>/<status>')
def status(id, status):
    with db() as conn:
        conn.execute("UPDATE servis SET status=? WHERE id=?", (status, id))
    return redirect('/')

@app.route('/servis/delete/<int:id>')
def delete(id):
    with db() as conn:
        conn.execute("DELETE FROM servis WHERE id=?", (id,))
    return redirect('/')

@app.route('/struk/<int:id>')
def struk(id):
    with db() as conn:
        data = conn.execute("""
            SELECT s.*, p.nama, p.hp, p.alamat
            FROM servis s
            LEFT JOIN pelanggan p ON s.pelanggan_id = p.id
            WHERE s.id=?
        """, (id,)).fetchone()

    return render_template("struk_thermal.html", data=data)

@app.route('/invoice/<int:id>')
def invoice(id):
    with db() as conn:
        data = conn.execute("""
            SELECT s.*, p.nama, p.hp, p.alamat
            FROM servis s
            LEFT JOIN pelanggan p ON s.pelanggan_id = p.id
            WHERE s.id=?
        """, (id,)).fetchone()

    return render_template("invoice.html", data=data)

# ================= RUN =================
if __name__ == '__main__':
    app.run(debug=True)